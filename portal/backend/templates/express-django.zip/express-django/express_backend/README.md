# To get started
Install node version 14+ in your system

# Run the following commands
npm install 

npm start

By default the app will run on port 3001
If running app on any other port, change the URL in in frontend code