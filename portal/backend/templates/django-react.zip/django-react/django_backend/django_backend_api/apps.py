from django.apps import AppConfig


class DjangoBackendApiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'django_backend_api'
